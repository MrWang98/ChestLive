import numpy as np
import scipy.io as scio

Range1 = range(1,6);

for i in Range1:
    print(i)

